
  # Admin dashboard with dark theme

  This is a code bundle for Admin dashboard with dark theme. The original project is available at https://www.figma.com/design/X1WFnqwC5gDZitMkGF5nQ0/Admin-dashboard-with-dark-theme.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  