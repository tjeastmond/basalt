import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "../ui/avatar";
import { Badge } from "../ui/badge";
import { MoreVertical } from "lucide-react";

const users = [
  {
    id: 1,
    name: "Alice Cooper",
    email: "alice.cooper@example.com",
    role: "Admin",
    status: "active",
    avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop",
  },
  {
    id: 2,
    name: "Bob Wilson",
    email: "bob.wilson@example.com",
    role: "User",
    status: "active",
    avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop",
  },
  {
    id: 3,
    name: "Carol Martinez",
    email: "carol.martinez@example.com",
    role: "User",
    status: "inactive",
    avatar: "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=100&h=100&fit=crop",
  },
  {
    id: 4,
    name: "David Lee",
    email: "david.lee@example.com",
    role: "Moderator",
    status: "active",
    avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop",
  },
  {
    id: 5,
    name: "Emma Thompson",
    email: "emma.thompson@example.com",
    role: "User",
    status: "active",
    avatar: "https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=100&h=100&fit=crop",
  },
];

export function Users() {
  return (
    <div className="p-8 bg-white dark:bg-zinc-950">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-semibold text-zinc-900 dark:text-white mb-2">Users</h1>
        <p className="text-zinc-600 dark:text-zinc-400">Manage your user accounts and permissions.</p>
      </div>

      {/* Users List */}
      <Card className="bg-white dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800">
        <CardHeader>
          <CardTitle className="text-zinc-900 dark:text-white">All Users</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {users.map((user) => (
              <div
                key={user.id}
                className="flex items-center justify-between p-4 rounded-lg border border-zinc-200 dark:border-zinc-800 hover:bg-zinc-100 dark:hover:bg-zinc-800/50 transition-colors"
              >
                <div className="flex items-center gap-4">
                  <Avatar className="h-10 w-10">
                    <AvatarImage src={user.avatar} alt={user.name} />
                    <AvatarFallback className="bg-zinc-200 dark:bg-zinc-700 text-zinc-900 dark:text-white">
                      {user.name.split(' ').map(n => n[0]).join('')}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="text-sm font-medium text-zinc-900 dark:text-white">{user.name}</p>
                    <p className="text-xs text-zinc-600 dark:text-zinc-400">{user.email}</p>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <Badge
                    variant={user.status === "active" ? "default" : "secondary"}
                    className={
                      user.status === "active"
                        ? "bg-green-500/20 text-green-600 dark:text-green-400 border-green-500/30"
                        : "bg-zinc-200 dark:bg-zinc-700 text-zinc-700 dark:text-zinc-400 border-zinc-300 dark:border-zinc-600"
                    }
                  >
                    {user.status}
                  </Badge>
                  <span className="text-sm text-zinc-600 dark:text-zinc-400 min-w-[80px]">{user.role}</span>
                  <button className="text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white transition-colors">
                    <MoreVertical className="w-5 h-5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}