import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import { BarChart3, TrendingUp, Users, Eye } from "lucide-react";

const metrics = [
  { name: "Page Views", value: "45,234", icon: Eye, color: "text-blue-500" },
  { name: "Unique Visitors", value: "12,543", icon: Users, color: "text-green-500" },
  { name: "Avg. Session", value: "3m 24s", icon: TrendingUp, color: "text-purple-500" },
  { name: "Bounce Rate", value: "42.3%", icon: BarChart3, color: "text-orange-500" },
];

export function Analytics() {
  return (
    <div className="p-8 bg-white dark:bg-zinc-950">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-semibold text-zinc-900 dark:text-white mb-2">Analytics</h1>
        <p className="text-zinc-600 dark:text-zinc-400">Track your performance metrics and insights.</p>
      </div>

      {/* Metrics Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {metrics.map((metric) => {
          const Icon = metric.icon;
          return (
            <Card key={metric.name} className="bg-white dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-zinc-600 dark:text-zinc-400">
                  {metric.name}
                </CardTitle>
                <Icon className={`h-5 w-5 ${metric.color}`} />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-semibold text-zinc-900 dark:text-white">
                  {metric.value}
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Chart Placeholder */}
      <Card className="bg-white dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800">
        <CardHeader>
          <CardTitle className="text-zinc-900 dark:text-white">Traffic Overview</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-64 flex items-center justify-center border-2 border-dashed border-zinc-300 dark:border-zinc-800 rounded-lg">
            <p className="text-zinc-500">Chart visualization would go here</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}