import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../ui/card";
import { Label } from "../ui/label";
import { Input } from "../ui/input";
import { Button } from "../ui/button";
import { Switch } from "../ui/switch";
import { Separator } from "../ui/separator";

export function Settings() {
  return (
    <div className="p-8 bg-white dark:bg-zinc-950">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-semibold text-zinc-900 dark:text-white mb-2">Settings</h1>
        <p className="text-zinc-600 dark:text-zinc-400">Manage your account settings and preferences.</p>
      </div>

      <div className="max-w-3xl space-y-6">
        {/* Profile Settings */}
        <Card className="bg-white dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800">
          <CardHeader>
            <CardTitle className="text-zinc-900 dark:text-white">Profile</CardTitle>
            <CardDescription className="text-zinc-600 dark:text-zinc-400">
              Update your personal information
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name" className="text-zinc-700 dark:text-zinc-300">Full Name</Label>
              <Input
                id="name"
                defaultValue="Sarah Johnson"
                className="bg-zinc-100 dark:bg-zinc-950 border-zinc-300 dark:border-zinc-800 text-zinc-900 dark:text-white"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="email" className="text-zinc-700 dark:text-zinc-300">Email</Label>
              <Input
                id="email"
                type="email"
                defaultValue="sarah.johnson@company.com"
                className="bg-zinc-100 dark:bg-zinc-950 border-zinc-300 dark:border-zinc-800 text-zinc-900 dark:text-white"
              />
            </div>
            <Button className="bg-zinc-900 dark:bg-white text-white dark:text-zinc-900 hover:bg-zinc-800 dark:hover:bg-zinc-200">
              Save Changes
            </Button>
          </CardContent>
        </Card>

        {/* Notifications */}
        <Card className="bg-white dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800">
          <CardHeader>
            <CardTitle className="text-zinc-900 dark:text-white">Notifications</CardTitle>
            <CardDescription className="text-zinc-600 dark:text-zinc-400">
              Configure how you receive notifications
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-zinc-900 dark:text-white">Email Notifications</p>
                <p className="text-sm text-zinc-600 dark:text-zinc-400">Receive email updates about your account</p>
              </div>
              <Switch defaultChecked />
            </div>
            <Separator className="bg-zinc-200 dark:bg-zinc-800" />
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-zinc-900 dark:text-white">Push Notifications</p>
                <p className="text-sm text-zinc-600 dark:text-zinc-400">Receive push notifications on your devices</p>
              </div>
              <Switch />
            </div>
            <Separator className="bg-zinc-200 dark:bg-zinc-800" />
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-zinc-900 dark:text-white">Weekly Reports</p>
                <p className="text-sm text-zinc-600 dark:text-zinc-400">Get weekly analytics reports via email</p>
              </div>
              <Switch defaultChecked />
            </div>
          </CardContent>
        </Card>

        {/* Security */}
        <Card className="bg-white dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800">
          <CardHeader>
            <CardTitle className="text-zinc-900 dark:text-white">Security</CardTitle>
            <CardDescription className="text-zinc-600 dark:text-zinc-400">
              Manage your password and security settings
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="current-password" className="text-zinc-700 dark:text-zinc-300">Current Password</Label>
              <Input
                id="current-password"
                type="password"
                className="bg-zinc-100 dark:bg-zinc-950 border-zinc-300 dark:border-zinc-800 text-zinc-900 dark:text-white"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="new-password" className="text-zinc-700 dark:text-zinc-300">New Password</Label>
              <Input
                id="new-password"
                type="password"
                className="bg-zinc-100 dark:bg-zinc-950 border-zinc-300 dark:border-zinc-800 text-zinc-900 dark:text-white"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="confirm-password" className="text-zinc-700 dark:text-zinc-300">Confirm Password</Label>
              <Input
                id="confirm-password"
                type="password"
                className="bg-zinc-100 dark:bg-zinc-950 border-zinc-300 dark:border-zinc-800 text-zinc-900 dark:text-white"
              />
            </div>
            <Button className="bg-zinc-900 dark:bg-white text-white dark:text-zinc-900 hover:bg-zinc-800 dark:hover:bg-zinc-200">
              Update Password
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}