import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../ui/card";
import { Button } from "../ui/button";
import { Badge } from "../ui/badge";
import { CreditCard, Download, Calendar } from "lucide-react";

const invoices = [
  { id: "INV-001", date: "March 1, 2026", amount: "$99.00", status: "paid" },
  { id: "INV-002", date: "February 1, 2026", amount: "$99.00", status: "paid" },
  { id: "INV-003", date: "January 1, 2026", amount: "$99.00", status: "paid" },
  { id: "INV-004", date: "December 1, 2025", amount: "$99.00", status: "paid" },
];

export function Billing() {
  return (
    <div className="p-8 bg-white dark:bg-zinc-950">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-semibold text-zinc-900 dark:text-white mb-2">Billing</h1>
        <p className="text-zinc-600 dark:text-zinc-400">Manage your subscription and billing information.</p>
      </div>

      <div className="max-w-4xl space-y-6">
        {/* Current Plan */}
        <Card className="bg-white dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800">
          <CardHeader>
            <CardTitle className="text-zinc-900 dark:text-white">Current Plan</CardTitle>
            <CardDescription className="text-zinc-600 dark:text-zinc-400">
              You are currently on the Pro plan
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-2xl font-semibold text-zinc-900 dark:text-white mb-1">Pro Plan</h3>
                <p className="text-zinc-600 dark:text-zinc-400 mb-4">$99.00 per month</p>
                <div className="flex items-center gap-2 text-sm text-zinc-600 dark:text-zinc-400">
                  <Calendar className="w-4 h-4" />
                  <span>Next billing date: April 1, 2026</span>
                </div>
              </div>
              <div className="flex gap-3">
                <Button variant="outline" className="border-zinc-300 dark:border-zinc-700 text-zinc-700 dark:text-zinc-300 hover:bg-zinc-100 dark:hover:bg-zinc-800">
                  Change Plan
                </Button>
                <Button variant="outline" className="border-zinc-300 dark:border-zinc-700 text-zinc-700 dark:text-zinc-300 hover:bg-zinc-100 dark:hover:bg-zinc-800">
                  Cancel Subscription
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Payment Method */}
        <Card className="bg-white dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800">
          <CardHeader>
            <CardTitle className="text-zinc-900 dark:text-white">Payment Method</CardTitle>
            <CardDescription className="text-zinc-600 dark:text-zinc-400">
              Update your payment information
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-zinc-100 dark:bg-zinc-800 rounded-lg flex items-center justify-center">
                  <CreditCard className="w-6 h-6 text-zinc-600 dark:text-zinc-400" />
                </div>
                <div>
                  <p className="text-sm font-medium text-zinc-900 dark:text-white">Visa ending in 4242</p>
                  <p className="text-xs text-zinc-600 dark:text-zinc-400">Expires 12/2027</p>
                </div>
              </div>
              <Button variant="outline" className="border-zinc-300 dark:border-zinc-700 text-zinc-700 dark:text-zinc-300 hover:bg-zinc-100 dark:hover:bg-zinc-800">
                Update
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Billing History */}
        <Card className="bg-white dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800">
          <CardHeader>
            <CardTitle className="text-zinc-900 dark:text-white">Billing History</CardTitle>
            <CardDescription className="text-zinc-600 dark:text-zinc-400">
              Download your previous invoices
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {invoices.map((invoice) => (
                <div
                  key={invoice.id}
                  className="flex items-center justify-between p-4 rounded-lg border border-zinc-200 dark:border-zinc-800 hover:bg-zinc-100 dark:hover:bg-zinc-800/50 transition-colors"
                >
                  <div className="flex items-center gap-4">
                    <div>
                      <p className="text-sm font-medium text-zinc-900 dark:text-white">{invoice.id}</p>
                      <p className="text-xs text-zinc-600 dark:text-zinc-400">{invoice.date}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <span className="text-sm text-zinc-900 dark:text-white font-medium min-w-[80px]">
                      {invoice.amount}
                    </span>
                    <Badge
                      className="bg-green-500/20 text-green-600 dark:text-green-400 border-green-500/30 min-w-[60px] justify-center"
                    >
                      {invoice.status}
                    </Badge>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white"
                    >
                      <Download className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}