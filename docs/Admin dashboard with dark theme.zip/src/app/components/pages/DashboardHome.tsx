import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import { ArrowUpRight, ArrowDownRight, Users, ShoppingCart, DollarSign, Activity } from "lucide-react";

const stats = [
  {
    name: "Total Revenue",
    value: "$45,231",
    change: "+20.1%",
    trending: "up",
    icon: DollarSign,
  },
  {
    name: "Active Users",
    value: "2,345",
    change: "+12.5%",
    trending: "up",
    icon: Users,
  },
  {
    name: "Orders",
    value: "1,234",
    change: "-5.2%",
    trending: "down",
    icon: ShoppingCart,
  },
  {
    name: "Conversion Rate",
    value: "3.24%",
    change: "+2.4%",
    trending: "up",
    icon: Activity,
  },
];

const recentActivity = [
  { id: 1, user: "John Doe", action: "Created new account", time: "2 minutes ago" },
  { id: 2, user: "Jane Smith", action: "Updated profile", time: "15 minutes ago" },
  { id: 3, user: "Mike Johnson", action: "Made a purchase", time: "1 hour ago" },
  { id: 4, user: "Sarah Williams", action: "Submitted support ticket", time: "2 hours ago" },
  { id: 5, user: "Tom Brown", action: "Left a review", time: "3 hours ago" },
];

export function DashboardHome() {
  return (
    <div className="p-8 bg-white dark:bg-zinc-950">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-semibold text-zinc-900 dark:text-white mb-2">Dashboard</h1>
        <p className="text-zinc-600 dark:text-zinc-400">Welcome back! Here's what's happening today.</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <Card key={stat.name} className="bg-white dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-zinc-600 dark:text-zinc-400">
                  {stat.name}
                </CardTitle>
                <Icon className="h-4 w-4 text-zinc-600 dark:text-zinc-400" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-semibold text-zinc-900 dark:text-white mb-1">
                  {stat.value}
                </div>
                <div className="flex items-center text-xs">
                  {stat.trending === "up" ? (
                    <ArrowUpRight className="w-4 h-4 text-green-500 mr-1" />
                  ) : (
                    <ArrowDownRight className="w-4 h-4 text-red-500 mr-1" />
                  )}
                  <span className={stat.trending === "up" ? "text-green-500" : "text-red-500"}>
                    {stat.change}
                  </span>
                  <span className="text-zinc-600 dark:text-zinc-400 ml-1">from last month</span>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Recent Activity */}
      <Card className="bg-white dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800">
        <CardHeader>
          <CardTitle className="text-zinc-900 dark:text-white">Recent Activity</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {recentActivity.map((activity) => (
              <div key={activity.id} className="flex items-start justify-between py-3 border-b border-zinc-200 dark:border-zinc-800 last:border-0">
                <div>
                  <p className="text-sm text-zinc-900 dark:text-white font-medium">{activity.user}</p>
                  <p className="text-sm text-zinc-600 dark:text-zinc-400">{activity.action}</p>
                </div>
                <span className="text-xs text-zinc-500">{activity.time}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}