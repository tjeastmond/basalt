import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../ui/card";
import { Button } from "../ui/button";
import { Badge } from "../ui/badge";
import { Switch } from "../ui/switch";
import { Separator } from "../ui/separator";
import { Smartphone, Monitor, Shield, Key, AlertCircle } from "lucide-react";

const activeSessions = [
  {
    id: 1,
    device: "MacBook Pro",
    location: "San Francisco, CA",
    lastActive: "Active now",
    current: true,
    icon: Monitor,
  },
  {
    id: 2,
    device: "iPhone 14 Pro",
    location: "San Francisco, CA",
    lastActive: "2 hours ago",
    current: false,
    icon: Smartphone,
  },
  {
    id: 3,
    device: "Chrome on Windows",
    location: "New York, NY",
    lastActive: "1 day ago",
    current: false,
    icon: Monitor,
  },
];

export function Security() {
  return (
    <div className="p-8 bg-white dark:bg-zinc-950">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-semibold text-zinc-900 dark:text-white mb-2">Security</h1>
        <p className="text-zinc-600 dark:text-zinc-400">Manage your account security and active sessions.</p>
      </div>

      <div className="max-w-4xl space-y-6">
        {/* Two-Factor Authentication */}
        <Card className="bg-white dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800">
          <CardHeader>
            <CardTitle className="text-zinc-900 dark:text-white flex items-center gap-2">
              <Shield className="w-5 h-5" />
              Two-Factor Authentication
            </CardTitle>
            <CardDescription className="text-zinc-600 dark:text-zinc-400">
              Add an extra layer of security to your account
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-zinc-900 dark:text-white">Authenticator App</p>
                <p className="text-sm text-zinc-600 dark:text-zinc-400">Use an authenticator app to generate codes</p>
              </div>
              <Switch />
            </div>
            <Separator className="bg-zinc-200 dark:bg-zinc-800" />
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-zinc-900 dark:text-white">SMS Authentication</p>
                <p className="text-sm text-zinc-600 dark:text-zinc-400">Receive codes via text message</p>
              </div>
              <Switch />
            </div>
          </CardContent>
        </Card>

        {/* API Keys */}
        <Card className="bg-white dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800">
          <CardHeader>
            <CardTitle className="text-zinc-900 dark:text-white flex items-center gap-2">
              <Key className="w-5 h-5" />
              API Keys
            </CardTitle>
            <CardDescription className="text-zinc-600 dark:text-zinc-400">
              Manage your API access keys
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-center justify-between p-4 rounded-lg border border-zinc-200 dark:border-zinc-800">
                <div>
                  <p className="text-sm font-medium text-zinc-900 dark:text-white mb-1">Production Key</p>
                  <code className="text-xs text-zinc-600 dark:text-zinc-400 bg-zinc-100 dark:bg-zinc-950 px-2 py-1 rounded">
                    sk_live_••••••••••••••••1234
                  </code>
                </div>
                <div className="flex items-center gap-3">
                  <Badge className="bg-green-500/20 text-green-600 dark:text-green-400 border-green-500/30">
                    Active
                  </Badge>
                  <Button variant="ghost" size="sm" className="text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white">
                    Revoke
                  </Button>
                </div>
              </div>
              <div className="flex items-center justify-between p-4 rounded-lg border border-zinc-200 dark:border-zinc-800">
                <div>
                  <p className="text-sm font-medium text-zinc-900 dark:text-white mb-1">Development Key</p>
                  <code className="text-xs text-zinc-600 dark:text-zinc-400 bg-zinc-100 dark:bg-zinc-950 px-2 py-1 rounded">
                    sk_test_••••••••••••••••5678
                  </code>
                </div>
                <div className="flex items-center gap-3">
                  <Badge className="bg-green-500/20 text-green-600 dark:text-green-400 border-green-500/30">
                    Active
                  </Badge>
                  <Button variant="ghost" size="sm" className="text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white">
                    Revoke
                  </Button>
                </div>
              </div>
              <Button variant="outline" className="w-full border-zinc-300 dark:border-zinc-700 text-zinc-700 dark:text-zinc-300 hover:bg-zinc-100 dark:hover:bg-zinc-800">
                Generate New Key
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Active Sessions */}
        <Card className="bg-white dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800">
          <CardHeader>
            <CardTitle className="text-zinc-900 dark:text-white">Active Sessions</CardTitle>
            <CardDescription className="text-zinc-600 dark:text-zinc-400">
              Manage devices that are currently logged in
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {activeSessions.map((session) => {
                const Icon = session.icon;
                return (
                  <div
                    key={session.id}
                    className="flex items-center justify-between p-4 rounded-lg border border-zinc-200 dark:border-zinc-800"
                  >
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 bg-zinc-100 dark:bg-zinc-800 rounded-lg flex items-center justify-center">
                        <Icon className="w-5 h-5 text-zinc-600 dark:text-zinc-400" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <p className="text-sm font-medium text-zinc-900 dark:text-white">{session.device}</p>
                          {session.current && (
                            <Badge className="bg-blue-500/20 text-blue-600 dark:text-blue-400 border-blue-500/30 text-xs">
                              Current
                            </Badge>
                          )}
                        </div>
                        <p className="text-xs text-zinc-600 dark:text-zinc-400">{session.location}</p>
                        <p className="text-xs text-zinc-500">{session.lastActive}</p>
                      </div>
                    </div>
                    {!session.current && (
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-red-500 dark:text-red-400 hover:text-red-600 dark:hover:text-red-300 hover:bg-red-50 dark:hover:bg-red-500/10"
                      >
                        Revoke
                      </Button>
                    )}
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Danger Zone */}
        <Card className="bg-white dark:bg-zinc-900 border-red-200 dark:border-red-900/50">
          <CardHeader>
            <CardTitle className="text-zinc-900 dark:text-white flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-red-500 dark:text-red-400" />
              Danger Zone
            </CardTitle>
            <CardDescription className="text-zinc-600 dark:text-zinc-400">
              Irreversible actions for your account
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between p-4 rounded-lg border border-red-200 dark:border-red-900/50 bg-red-50 dark:bg-red-950/20">
              <div>
                <p className="text-sm font-medium text-zinc-900 dark:text-white">Delete Account</p>
                <p className="text-sm text-zinc-600 dark:text-zinc-400">Permanently delete your account and all data</p>
              </div>
              <Button
                variant="destructive"
                className="bg-red-600 hover:bg-red-700 text-white"
              >
                Delete Account
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}