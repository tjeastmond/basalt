import { createBrowserRouter } from "react-router";
import { DashboardLayout } from "./components/DashboardLayout";
import { DashboardHome } from "./components/pages/DashboardHome";
import { Analytics } from "./components/pages/Analytics";
import { Users } from "./components/pages/Users";
import { Settings } from "./components/pages/Settings";
import { Team } from "./components/pages/Team";
import { Billing } from "./components/pages/Billing";
import { Security } from "./components/pages/Security";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: DashboardLayout,
    children: [
      { index: true, Component: DashboardHome },
      { path: "analytics", Component: Analytics },
      { path: "users", Component: Users },
      { path: "settings", Component: Settings },
      { path: "team", Component: Team },
      { path: "billing", Component: Billing },
      { path: "security", Component: Security },
    ],
  },
]);